import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Student = {
  id: string;
  name: string;
  email: string;
  phone: string;
  roll_number: string;
  class: string;
  section: string;
  gender: string;
  dob: string | null;
  address: string;
  guardian_name: string;
  guardian_phone: string;
  status: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

export type Subject = {
  id: string;
  name: string;
  code: string;
  class: string;
  teacher_id: string | null;
  created_at: string;
};

export type Attendance = {
  id: string;
  student_id: string;
  subject_id: string | null;
  date: string;
  status: string;
  marked_by: string | null;
  created_at: string;
  students?: Pick<Student, 'name' | 'roll_number' | 'class'>;
  subjects?: Pick<Subject, 'name' | 'code'>;
};

export type Mark = {
  id: string;
  student_id: string;
  subject_id: string;
  exam_type: string;
  marks_obtained: number;
  total_marks: number;
  grade: string;
  remarks: string;
  entered_by: string | null;
  created_at: string;
  updated_at: string;
  students?: Pick<Student, 'name' | 'roll_number' | 'class'>;
  subjects?: Pick<Subject, 'name' | 'code'>;
};
