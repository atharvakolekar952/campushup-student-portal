import React from 'react';
import { AlertTriangle } from 'lucide-react';
import Modal from './Modal';

type Props = {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  loading?: boolean;
};

export default function ConfirmDialog({ isOpen, onClose, onConfirm, title, message, confirmLabel = 'Delete', loading }: Props) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="sm">
      <div className="flex flex-col items-center text-center gap-4">
        <div className="w-14 h-14 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
          <AlertTriangle size={24} className="text-red-600 dark:text-red-400" />
        </div>
        <p className="text-slate-600 dark:text-slate-300 text-sm">{message}</p>
        <div className="flex gap-3 w-full mt-2">
          <button onClick={onClose} className="flex-1 btn-secondary">Cancel</button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className="flex-1 btn-danger"
          >
            {loading ? 'Deleting...' : confirmLabel}
          </button>
        </div>
      </div>
    </Modal>
  );
}
