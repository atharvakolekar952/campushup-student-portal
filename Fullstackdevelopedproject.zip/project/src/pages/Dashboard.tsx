import React, { useEffect, useState } from 'react';
import {
  Users, ClipboardList, Award, TrendingUp, TrendingDown,
  UserCheck, UserX, BookOpen, Activity, BarChart2,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

type Stats = {
  totalStudents: number;
  activeStudents: number;
  inactiveStudents: number;
  totalSubjects: number;
  attendanceToday: number;
  absentToday: number;
  avgMarks: number;
  recentStudents: Array<{ id: string; name: string; class: string; roll_number: string; status: string; created_at: string }>;
};

function StatCard({ icon: Icon, label, value, sub, color, trend }: {
  icon: React.ElementType; label: string; value: string | number; sub?: string;
  color: string; trend?: 'up' | 'down' | null;
}) {
  return (
    <div className="stat-card">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon size={22} className="text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
        <p className="text-2xl font-bold font-display text-slate-900 dark:text-white mt-0.5">{value}</p>
        {sub && (
          <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
            {trend === 'up' && <TrendingUp size={11} className="text-emerald-500" />}
            {trend === 'down' && <TrendingDown size={11} className="text-red-500" />}
            {sub}
          </p>
        )}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats>({
    totalStudents: 0, activeStudents: 0, inactiveStudents: 0,
    totalSubjects: 0, attendanceToday: 0, absentToday: 0,
    avgMarks: 0, recentStudents: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const today = new Date().toISOString().split('T')[0];

      const [studentsRes, subjectsRes, attendanceRes, marksRes, recentRes] = await Promise.all([
        supabase.from('students').select('id, status'),
        supabase.from('subjects').select('id'),
        supabase.from('attendance').select('id, status').eq('date', today),
        supabase.from('marks').select('marks_obtained, total_marks'),
        supabase.from('students').select('id, name, class, roll_number, status, created_at').order('created_at', { ascending: false }).limit(5),
      ]);

      const students = studentsRes.data ?? [];
      const active = students.filter(s => s.status === 'active').length;
      const absent = (attendanceRes.data ?? []).filter(a => a.status === 'absent').length;
      const present = (attendanceRes.data ?? []).filter(a => a.status === 'present').length;

      const allMarks = marksRes.data ?? [];
      const avg = allMarks.length
        ? allMarks.reduce((sum, m) => sum + (m.marks_obtained / m.total_marks) * 100, 0) / allMarks.length
        : 0;

      setStats({
        totalStudents: students.length,
        activeStudents: active,
        inactiveStudents: students.length - active,
        totalSubjects: subjectsRes.data?.length ?? 0,
        attendanceToday: present,
        absentToday: absent,
        avgMarks: Math.round(avg),
        recentStudents: recentRes.data ?? [],
      });
      setLoading(false);
    }
    load();
  }, []);

  const userName = user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Admin';
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const attendanceRate = stats.totalStudents > 0
    ? Math.round((stats.attendanceToday / stats.totalStudents) * 100)
    : 0;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-700 to-blue-500 rounded-2xl p-6 shadow-glow-blue">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/4" />
        <div className="absolute bottom-0 left-1/3 w-32 h-32 bg-white/5 rounded-full translate-y-1/2" />
        <div className="relative">
          <p className="text-blue-200 text-sm font-medium">{greeting},</p>
          <h2 className="font-display text-2xl font-bold text-white mt-0.5">{userName}!</h2>
          <p className="text-blue-200 text-sm mt-2">
            Here's what's happening at CampusHub today.
          </p>
        </div>
        <div className="relative mt-4 flex gap-6">
          <div>
            <p className="text-blue-200 text-xs">Today's Date</p>
            <p className="text-white font-semibold text-sm">{new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          icon={Users}
          label="Total Students"
          value={stats.totalStudents}
          sub={`${stats.activeStudents} active`}
          color="bg-blue-600"
          trend="up"
        />
        <StatCard
          icon={UserCheck}
          label="Present Today"
          value={stats.attendanceToday}
          sub={`${attendanceRate}% attendance rate`}
          color="bg-emerald-600"
          trend={attendanceRate >= 75 ? 'up' : 'down'}
        />
        <StatCard
          icon={BarChart2}
          label="Avg. Score"
          value={`${stats.avgMarks}%`}
          sub="Across all subjects"
          color="bg-amber-500"
        />
        <StatCard
          icon={BookOpen}
          label="Subjects"
          value={stats.totalSubjects}
          sub="Active courses"
          color="bg-cyan-600"
        />
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card p-5">
          <div className="flex items-center gap-3 mb-4">
            <Activity size={18} className="text-emerald-500" />
            <h3 className="font-semibold text-slate-900 dark:text-white text-sm">Student Status</h3>
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-500">Active</span>
                <span className="font-semibold text-slate-900 dark:text-white">{stats.activeStudents}</span>
              </div>
              <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-700"
                  style={{ width: stats.totalStudents ? `${(stats.activeStudents / stats.totalStudents) * 100}%` : '0%' }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-500">Inactive</span>
                <span className="font-semibold text-slate-900 dark:text-white">{stats.inactiveStudents}</span>
              </div>
              <div className="h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-slate-400 rounded-full transition-all duration-700"
                  style={{ width: stats.totalStudents ? `${(stats.inactiveStudents / stats.totalStudents) * 100}%` : '0%' }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-3 mb-4">
            <ClipboardList size={18} className="text-blue-500" />
            <h3 className="font-semibold text-slate-900 dark:text-white text-sm">Today's Attendance</h3>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-24 h-24">
              <svg className="w-24 h-24 -rotate-90">
                <circle cx="48" cy="48" r="38" fill="none" stroke="#1e293b" strokeWidth="8" />
                <circle
                  cx="48" cy="48" r="38" fill="none"
                  stroke="#3b82f6" strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 38}`}
                  strokeDashoffset={`${2 * Math.PI * 38 * (1 - attendanceRate / 100)}`}
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold font-display text-slate-900 dark:text-white">{attendanceRate}%</span>
              </div>
            </div>
            <div className="ml-4 space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                <span className="text-xs text-slate-500">Present: {stats.attendanceToday}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                <span className="text-xs text-slate-500">Absent: {stats.absentToday}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-3 mb-4">
            <Award size={18} className="text-amber-500" />
            <h3 className="font-semibold text-slate-900 dark:text-white text-sm">Performance</h3>
          </div>
          <div className="space-y-2">
            {[
              { label: 'Excellent (90%+)', pct: 30, color: 'bg-emerald-500' },
              { label: 'Good (75-89%)', pct: 45, color: 'bg-blue-500' },
              { label: 'Average (50-74%)', pct: 20, color: 'bg-amber-500' },
              { label: 'Below Avg (<50%)', pct: 5, color: 'bg-red-500' },
            ].map(item => (
              <div key={item.label}>
                <div className="flex justify-between text-xs mb-0.5">
                  <span className="text-slate-500">{item.label}</span>
                  <span className="text-slate-400">{item.pct}%</span>
                </div>
                <div className="h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent students */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700">
          <h3 className="font-display font-semibold text-slate-900 dark:text-white">Recently Added Students</h3>
          <span className="text-xs text-slate-400">Last 5 entries</span>
        </div>
        {stats.recentStudents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-slate-400">
            <UserX size={32} className="mb-3 opacity-50" />
            <p className="text-sm">No students added yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  {['Name', 'Roll No.', 'Class', 'Status', 'Added'].map(h => (
                    <th key={h} className="table-header text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {stats.recentStudents.map(s => (
                  <tr key={s.id} className="table-row">
                    <td className="table-cell font-medium text-slate-900 dark:text-white">{s.name}</td>
                    <td className="table-cell font-mono text-xs">{s.roll_number}</td>
                    <td className="table-cell">{s.class}</td>
                    <td className="table-cell">
                      <span className={s.status === 'active' ? 'badge-active' : 'badge-inactive'}>
                        {s.status}
                      </span>
                    </td>
                    <td className="table-cell text-slate-400">
                      {new Date(s.created_at).toLocaleDateString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
