import React, { useEffect, useState, useCallback } from 'react';
import {
  UserPlus, Edit2, Trash2, Filter, Upload,
  ChevronDown, UserX, Phone, MapPin, Users,
} from 'lucide-react';
import { supabase, type Student } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import SearchBar from '../components/SearchBar';

const CLASSES = ['10th', '11th', '12th'];
const GENDERS = ['Male', 'Female', 'Other'];

const emptyForm = {
  name: '', email: '', phone: '', roll_number: '', class: '',
  section: '', gender: '', dob: '', address: '', guardian_name: '',
  guardian_phone: '', status: 'active',
};

export default function Students() {
  const { user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [filtered, setFiltered] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editStudent, setEditStudent] = useState<Student | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');
  const [profileFile, setProfileFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');

  const fetchStudents = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('students')
      .select('*')
      .order('created_at', { ascending: false });
    setStudents(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchStudents(); }, [fetchStudents]);

  useEffect(() => {
    let result = students;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(s =>
        s.name.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        s.roll_number.toLowerCase().includes(q)
      );
    }
    if (classFilter) result = result.filter(s => s.class === classFilter);
    if (statusFilter) result = result.filter(s => s.status === statusFilter);
    setFiltered(result);
  }, [students, search, classFilter, statusFilter]);

  const openAdd = () => {
    setEditStudent(null);
    setForm(emptyForm);
    setProfileFile(null);
    setPreviewUrl('');
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (s: Student) => {
    setEditStudent(s);
    setForm({
      name: s.name, email: s.email, phone: s.phone || '',
      roll_number: s.roll_number, class: s.class || '',
      section: s.section || '', gender: s.gender || '',
      dob: s.dob || '', address: s.address || '',
      guardian_name: s.guardian_name || '',
      guardian_phone: s.guardian_phone || '',
      status: s.status || 'active',
    });
    setProfileFile(null);
    setPreviewUrl('');
    setFormError('');
    setModalOpen(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProfileFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);

    try {
      let profileImageUrl = editStudent?.profile_image_url || '';

      if (profileFile) {
        const ext = profileFile.name.split('.').pop();
        const path = `profiles/${Date.now()}.${ext}`;
        const { error: uploadErr } = await supabase.storage
          .from('student-profiles')
          .upload(path, profileFile, { upsert: true });
        if (!uploadErr) {
          const { data: urlData } = supabase.storage.from('student-profiles').getPublicUrl(path);
          profileImageUrl = urlData.publicUrl;
        }
      }

      const payload = {
        ...form,
        dob: form.dob || null,
        profile_image_url: profileImageUrl,
        updated_at: new Date().toISOString(),
      };

      if (editStudent) {
        const { error } = await supabase.from('students').update(payload).eq('id', editStudent.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('students').insert({ ...payload, created_by: user?.id });
        if (error) throw error;
      }

      setModalOpen(false);
      fetchStudents();
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : 'Failed to save student');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    await supabase.from('students').delete().eq('id', deleteId);
    setDeleteId(null);
    setDeleting(false);
    fetchStudents();
  };

  const field = (key: keyof typeof form, label: string, type = 'text', opts?: string[]) => (
    <div>
      <label className="label">{label}</label>
      {opts ? (
        <div className="relative">
          <select
            value={form[key]}
            onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
            className="input-field appearance-none pr-8"
          >
            <option value="">Select {label}</option>
            {opts.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
      ) : (
        <input
          type={type}
          value={form[key]}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          className="input-field"
          placeholder={`Enter ${label.toLowerCase()}`}
        />
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div>
          <h1 className="page-header">Students</h1>
          <p className="text-sm text-slate-500 mt-0.5">{filtered.length} of {students.length} students</p>
        </div>
        <button onClick={openAdd} className="btn-primary ml-auto flex items-center gap-2">
          <UserPlus size={16} />
          Add Student
        </button>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-wrap gap-3 items-center">
        <SearchBar value={search} onChange={setSearch} placeholder="Search by name, email, roll no..." className="flex-1 min-w-48" />

        <div className="relative">
          <select
            value={classFilter}
            onChange={e => setClassFilter(e.target.value)}
            className="input-field appearance-none pr-8 w-32"
          >
            <option value="">All Classes</option>
            {CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>

        <div className="relative">
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="input-field appearance-none pr-8 w-32"
          >
            <option value="">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
          <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>

        {(classFilter || statusFilter) && (
          <button
            onClick={() => { setClassFilter(''); setStatusFilter(''); }}
            className="text-xs text-blue-500 hover:text-blue-400 flex items-center gap-1"
          >
            <Filter size={12} /> Clear
          </button>
        )}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-slate-400">
            <UserX size={36} className="mb-3 opacity-40" />
            <p className="font-medium">No students found</p>
            <p className="text-sm mt-1 text-slate-500">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  {['Student', 'Roll No.', 'Class', 'Contact', 'Status', 'Actions'].map(h => (
                    <th key={h} className="table-header text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => (
                  <tr key={s.id} className="table-row group">
                    <td className="table-cell">
                      <div className="flex items-center gap-3">
                        {s.profile_image_url ? (
                          <img
                            src={s.profile_image_url}
                            alt={s.name}
                            className="w-9 h-9 rounded-full object-cover border-2 border-slate-200 dark:border-slate-700"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-bold text-white">
                              {s.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                            </span>
                          </div>
                        )}
                        <div>
                          <p className="font-medium text-slate-900 dark:text-white text-sm">{s.name}</p>
                          <p className="text-xs text-slate-400">{s.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="table-cell font-mono text-xs">{s.roll_number}</td>
                    <td className="table-cell">
                      <span className="text-sm">{s.class}</span>
                      {s.section && <span className="text-xs text-slate-400 ml-1">-{s.section}</span>}
                    </td>
                    <td className="table-cell">
                      <div className="space-y-0.5">
                        {s.phone && (
                          <div className="flex items-center gap-1 text-xs text-slate-500">
                            <Phone size={11} /> {s.phone}
                          </div>
                        )}
                        {s.address && (
                          <div className="flex items-center gap-1 text-xs text-slate-400">
                            <MapPin size={11} /> {s.address.split(',')[0]}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className={s.status === 'active' ? 'badge-active' : 'badge-inactive'}>
                        {s.status}
                      </span>
                    </td>
                    <td className="table-cell">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => openEdit(s)}
                          className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all"
                          title="Edit"
                        >
                          <Edit2 size={14} />
                        </button>
                        <button
                          onClick={() => setDeleteId(s.id)}
                          className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
                          title="Delete"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Stats bar */}
      <div className="flex gap-4 text-sm text-slate-500">
        <span className="flex items-center gap-1.5">
          <Users size={14} className="text-blue-500" />
          Total: <strong className="text-slate-900 dark:text-white">{students.length}</strong>
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          Active: <strong className="text-slate-900 dark:text-white">{students.filter(s => s.status === 'active').length}</strong>
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-slate-400" />
          Inactive: <strong className="text-slate-900 dark:text-white">{students.filter(s => s.status === 'inactive').length}</strong>
        </span>
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editStudent ? 'Edit Student' : 'Add New Student'}
        size="lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg px-3 py-2 text-sm">
              {formError}
            </div>
          )}

          {/* Profile photo */}
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full overflow-hidden bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
              {previewUrl || editStudent?.profile_image_url ? (
                <img src={previewUrl || editStudent?.profile_image_url} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <span className="text-lg font-bold text-white">
                  {form.name ? form.name[0]?.toUpperCase() : '?'}
                </span>
              )}
            </div>
            <div>
              <label className="cursor-pointer inline-flex items-center gap-2 text-sm text-blue-500 hover:text-blue-400 border border-blue-500/30 hover:border-blue-400 rounded-lg px-3 py-1.5 transition-all">
                <Upload size={14} />
                Upload Photo
                <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
              </label>
              <p className="text-xs text-slate-400 mt-1">JPG, PNG up to 2MB</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {field('name', 'Full Name')}
            {field('email', 'Email Address', 'email')}
            {field('phone', 'Phone Number', 'tel')}
            {field('roll_number', 'Roll Number')}
            {field('class', 'Class', 'text', CLASSES)}
            {field('section', 'Section')}
            {field('gender', 'Gender', 'text', GENDERS)}
            {field('dob', 'Date of Birth', 'date')}
            {field('guardian_name', 'Guardian Name')}
            {field('guardian_phone', 'Guardian Phone', 'tel')}
            {field('status', 'Status', 'text', ['active', 'inactive'])}
          </div>
          <div>
            <label className="label">Address</label>
            <textarea
              value={form.address}
              onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
              rows={2}
              className="input-field resize-none"
              placeholder="Enter address"
            />
          </div>

          <div className="flex gap-3 pt-2 border-t border-slate-200 dark:border-slate-700">
            <button type="button" onClick={() => setModalOpen(false)} className="flex-1 btn-secondary">Cancel</button>
            <button type="submit" disabled={saving} className="flex-1 btn-primary">
              {saving ? 'Saving...' : editStudent ? 'Update Student' : 'Add Student'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete confirm */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Student"
        message="This will permanently delete the student and all their records. This action cannot be undone."
        loading={deleting}
      />
    </div>
  );
}
