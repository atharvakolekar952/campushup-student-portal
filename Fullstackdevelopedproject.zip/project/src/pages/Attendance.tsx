import React, { useEffect, useState, useCallback } from 'react';
import {
  ClipboardList, CheckCircle, XCircle, Clock,
  ChevronDown, Filter, Save, Calendar,
  UserCheck, UserX,
} from 'lucide-react';
import { supabase, type Student, type Subject, type Attendance } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import SearchBar from '../components/SearchBar';

const STATUS_OPTIONS = ['present', 'absent', 'late'];

type AttendanceRow = {
  student: Student;
  status: string;
};

export default function AttendancePage() {
  const { user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [records, setRecords] = useState<Attendance[]>([]);
  const [rows, setRows] = useState<AttendanceRow[]>([]);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'mark' | 'history'>('mark');
  const [history, setHistory] = useState<Attendance[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const classes = [...new Set(students.map(s => s.class).filter(Boolean))];

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [studRes, subRes] = await Promise.all([
      supabase.from('students').select('*').eq('status', 'active').order('name'),
      supabase.from('subjects').select('*').order('name'),
    ]);
    setStudents(studRes.data ?? []);
    setSubjects(subRes.data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const fetchExisting = useCallback(async () => {
    if (!selectedDate || !selectedSubject) return;
    const { data } = await supabase
      .from('attendance')
      .select('*')
      .eq('date', selectedDate)
      .eq('subject_id', selectedSubject);
    setRecords(data ?? []);
  }, [selectedDate, selectedSubject]);

  useEffect(() => { fetchExisting(); }, [fetchExisting]);

  useEffect(() => {
    let filtered = students;
    if (classFilter) filtered = filtered.filter(s => s.class === classFilter);
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(s =>
        s.name.toLowerCase().includes(q) || s.roll_number.toLowerCase().includes(q)
      );
    }
    const newRows = filtered.map(student => {
      const existing = records.find(r => r.student_id === student.id);
      return { student, status: existing?.status ?? 'present' };
    });
    setRows(newRows);
  }, [students, records, classFilter, search]);

  const updateStatus = (studentId: string, status: string) => {
    setRows(prev => prev.map(r => r.student.id === studentId ? { ...r, status } : r));
  };

  const markAll = (status: string) => {
    setRows(prev => prev.map(r => ({ ...r, status })));
  };

  const handleSave = async () => {
    if (!selectedSubject || !selectedDate) return;
    setSaving(true);

    const upserts = rows.map(r => ({
      student_id: r.student.id,
      subject_id: selectedSubject,
      date: selectedDate,
      status: r.status,
      marked_by: user?.id,
    }));

    await supabase
      .from('attendance')
      .upsert(upserts, { onConflict: 'student_id,subject_id,date', ignoreDuplicates: false });

    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
    fetchExisting();
  };

  const fetchHistory = useCallback(async () => {
    setHistoryLoading(true);
    const { data } = await supabase
      .from('attendance')
      .select('*, students(name, roll_number, class), subjects(name, code)')
      .order('date', { ascending: false })
      .limit(100);
    setHistory(data ?? []);
    setHistoryLoading(false);
  }, []);

  useEffect(() => {
    if (tab === 'history') fetchHistory();
  }, [tab, fetchHistory]);

  const presentCount = rows.filter(r => r.status === 'present').length;
  const absentCount = rows.filter(r => r.status === 'absent').length;
  const lateCount = rows.filter(r => r.status === 'late').length;

  const statusIcon = (s: string) => {
    if (s === 'present') return <CheckCircle size={14} className="text-emerald-500" />;
    if (s === 'absent') return <XCircle size={14} className="text-red-500" />;
    return <Clock size={14} className="text-amber-500" />;
  };

  const statusBadge = (s: string) => {
    if (s === 'present') return 'badge-present';
    if (s === 'absent') return 'badge-absent';
    return 'badge-late';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">Attendance</h1>
          <p className="text-sm text-slate-500 mt-0.5">Mark and track student attendance</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl w-fit">
        {(['mark', 'history'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 capitalize ${
              tab === t
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            {t === 'mark' ? 'Mark Attendance' : 'History'}
          </button>
        ))}
      </div>

      {tab === 'mark' && (
        <>
          {/* Controls */}
          <div className="card p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="label">Date</label>
              <div className="relative">
                <Calendar size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={e => setSelectedDate(e.target.value)}
                  className="input-field pl-9"
                />
              </div>
            </div>
            <div>
              <label className="label">Subject</label>
              <div className="relative">
                <select
                  value={selectedSubject}
                  onChange={e => setSelectedSubject(e.target.value)}
                  className="input-field appearance-none pr-8"
                >
                  <option value="">Select Subject</option>
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                  ))}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>
            <div>
              <label className="label">Filter by Class</label>
              <div className="relative">
                <select
                  value={classFilter}
                  onChange={e => setClassFilter(e.target.value)}
                  className="input-field appearance-none pr-8"
                >
                  <option value="">All Classes</option>
                  {classes.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Summary + bulk actions */}
          <div className="flex flex-wrap gap-3 items-center">
            <div className="flex gap-3">
              <span className="flex items-center gap-1.5 text-sm text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1.5 rounded-lg">
                <UserCheck size={14} /> Present: {presentCount}
              </span>
              <span className="flex items-center gap-1.5 text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 px-3 py-1.5 rounded-lg">
                <UserX size={14} /> Absent: {absentCount}
              </span>
              <span className="flex items-center gap-1.5 text-sm text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-lg">
                <Clock size={14} /> Late: {lateCount}
              </span>
            </div>
            <div className="ml-auto flex gap-2">
              <button onClick={() => markAll('present')} className="text-xs btn-ghost border border-slate-300 dark:border-slate-600 py-1.5">
                Mark All Present
              </button>
              <button onClick={() => markAll('absent')} className="text-xs btn-ghost border border-slate-300 dark:border-slate-600 py-1.5">
                Mark All Absent
              </button>
            </div>
          </div>

          <SearchBar value={search} onChange={setSearch} placeholder="Search students..." className="max-w-sm" />

          {/* Student list */}
          <div className="card overflow-hidden">
            {rows.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-400">
                <ClipboardList size={36} className="mb-3 opacity-40" />
                <p className="font-medium">No students found</p>
                <p className="text-sm mt-1 text-slate-500">Add students first to mark attendance</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 dark:bg-slate-900/50">
                    <tr>
                      {['Student', 'Roll No.', 'Class', 'Status', 'Mark'].map(h => (
                        <th key={h} className="table-header text-left">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map(({ student, status }) => (
                      <tr key={student.id} className="table-row">
                        <td className="table-cell">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                              <span className="text-xs font-bold text-white">
                                {student.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                              </span>
                            </div>
                            <span className="font-medium text-slate-900 dark:text-white text-sm">{student.name}</span>
                          </div>
                        </td>
                        <td className="table-cell font-mono text-xs">{student.roll_number}</td>
                        <td className="table-cell text-sm">{student.class}</td>
                        <td className="table-cell">
                          <span className={`${statusBadge(status)} flex items-center gap-1 w-fit`}>
                            {statusIcon(status)}
                            {status}
                          </span>
                        </td>
                        <td className="table-cell">
                          <div className="flex gap-1.5">
                            {STATUS_OPTIONS.map(s => (
                              <button
                                key={s}
                                onClick={() => updateStatus(student.id, s)}
                                className={`
                                  px-2.5 py-1 rounded-md text-xs font-medium transition-all capitalize
                                  ${status === s
                                    ? s === 'present'
                                      ? 'bg-emerald-600 text-white'
                                      : s === 'absent'
                                        ? 'bg-red-600 text-white'
                                        : 'bg-amber-500 text-white'
                                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-600'
                                  }
                                `}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            {saved && (
              <span className="text-emerald-500 text-sm flex items-center gap-1.5 animate-fade-in">
                <CheckCircle size={15} /> Attendance saved successfully!
              </span>
            )}
            <button
              onClick={handleSave}
              disabled={saving || !selectedSubject || rows.length === 0}
              className="btn-primary ml-auto flex items-center gap-2"
            >
              <Save size={15} />
              {saving ? 'Saving...' : 'Save Attendance'}
            </button>
          </div>
        </>
      )}

      {tab === 'history' && (
        <div className="card overflow-hidden">
          {historyLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : history.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <ClipboardList size={36} className="mb-3 opacity-40" />
              <p>No attendance records yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 dark:bg-slate-900/50">
                  <tr>
                    {['Student', 'Roll No.', 'Subject', 'Date', 'Status'].map(h => (
                      <th key={h} className="table-header text-left">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {history.map(r => (
                    <tr key={r.id} className="table-row">
                      <td className="table-cell font-medium text-slate-900 dark:text-white">{(r as any).students?.name ?? '-'}</td>
                      <td className="table-cell font-mono text-xs">{(r as any).students?.roll_number ?? '-'}</td>
                      <td className="table-cell">{(r as any).subjects?.name ?? '-'}</td>
                      <td className="table-cell">{new Date(r.date).toLocaleDateString('en-IN')}</td>
                      <td className="table-cell">
                        <span className={`${statusBadge(r.status)} flex items-center gap-1 w-fit`}>
                          {statusIcon(r.status)}
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
