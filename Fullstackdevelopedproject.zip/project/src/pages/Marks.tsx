import React, { useEffect, useState, useCallback } from 'react';
import {
  Award, Plus, Edit2, Trash2, ChevronDown,
  BarChart2, TrendingUp,
} from 'lucide-react';
import { supabase, type Student, type Subject, type Mark } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import SearchBar from '../components/SearchBar';

const EXAM_TYPES = ['midterm', 'final', 'unit_test', 'assignment', 'practical'];

const emptyForm = {
  student_id: '',
  subject_id: '',
  exam_type: 'midterm',
  marks_obtained: '',
  total_marks: '100',
  grade: '',
  remarks: '',
};

function calcGrade(obtained: number, total: number): string {
  const pct = (obtained / total) * 100;
  if (pct >= 90) return 'A+';
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B+';
  if (pct >= 60) return 'B';
  if (pct >= 50) return 'C';
  if (pct >= 40) return 'D';
  return 'F';
}

function gradeColor(grade: string) {
  if (['A+', 'A'].includes(grade)) return 'text-emerald-500';
  if (['B+', 'B'].includes(grade)) return 'text-blue-500';
  if (grade === 'C') return 'text-amber-500';
  if (grade === 'D') return 'text-orange-500';
  return 'text-red-500';
}

export default function MarksPage() {
  const { user } = useAuth();
  const [marks, setMarks] = useState<Mark[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [filtered, setFiltered] = useState<Mark[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [examTypeFilter, setExamTypeFilter] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editMark, setEditMark] = useState<Mark | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const [marksRes, studRes, subRes] = await Promise.all([
      supabase
        .from('marks')
        .select('*, students(name, roll_number, class), subjects(name, code)')
        .order('created_at', { ascending: false }),
      supabase.from('students').select('id, name, roll_number, class').eq('status', 'active').order('name'),
      supabase.from('subjects').select('id, name, code').order('name'),
    ]);
    setMarks(marksRes.data ?? []);
    setStudents(studRes.data ?? []);
    setSubjects(subRes.data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  useEffect(() => {
    let result = marks;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(m =>
        (m as any).students?.name?.toLowerCase().includes(q) ||
        (m as any).students?.roll_number?.toLowerCase().includes(q)
      );
    }
    if (examTypeFilter) result = result.filter(m => m.exam_type === examTypeFilter);
    if (subjectFilter) result = result.filter(m => m.subject_id === subjectFilter);
    setFiltered(result);
  }, [marks, search, examTypeFilter, subjectFilter]);

  const openAdd = () => {
    setEditMark(null);
    setForm(emptyForm);
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (m: Mark) => {
    setEditMark(m);
    setForm({
      student_id: m.student_id,
      subject_id: m.subject_id,
      exam_type: m.exam_type,
      marks_obtained: String(m.marks_obtained),
      total_marks: String(m.total_marks),
      grade: m.grade || '',
      remarks: m.remarks || '',
    });
    setFormError('');
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);

    const obtained = parseFloat(form.marks_obtained);
    const total = parseFloat(form.total_marks);

    if (isNaN(obtained) || isNaN(total) || total <= 0) {
      setFormError('Please enter valid marks.');
      setSaving(false);
      return;
    }
    if (obtained > total) {
      setFormError('Marks obtained cannot exceed total marks.');
      setSaving(false);
      return;
    }

    const grade = form.grade || calcGrade(obtained, total);
    const payload = {
      student_id: form.student_id,
      subject_id: form.subject_id,
      exam_type: form.exam_type,
      marks_obtained: obtained,
      total_marks: total,
      grade,
      remarks: form.remarks,
      entered_by: user?.id,
      updated_at: new Date().toISOString(),
    };

    try {
      if (editMark) {
        const { error } = await supabase.from('marks').update(payload).eq('id', editMark.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('marks').insert(payload);
        if (error) throw error;
      }
      setModalOpen(false);
      fetchAll();
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : 'Failed to save marks');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    await supabase.from('marks').delete().eq('id', deleteId);
    setDeleteId(null);
    setDeleting(false);
    fetchAll();
  };

  const avgScore = filtered.length
    ? filtered.reduce((sum, m) => sum + (m.marks_obtained / m.total_marks) * 100, 0) / filtered.length
    : 0;

  const topScore = filtered.length
    ? Math.max(...filtered.map(m => (m.marks_obtained / m.total_marks) * 100))
    : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div>
          <h1 className="page-header">Marks</h1>
          <p className="text-sm text-slate-500 mt-0.5">{filtered.length} records</p>
        </div>
        <button onClick={openAdd} className="btn-primary ml-auto flex items-center gap-2">
          <Plus size={16} />
          Add Marks
        </button>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
            <BarChart2 size={18} className="text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Average Score</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-white">{avgScore.toFixed(1)}%</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg flex items-center justify-center">
            <TrendingUp size={18} className="text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Top Score</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-white">{topScore.toFixed(1)}%</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
            <Award size={18} className="text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <p className="text-xs text-slate-500">Total Records</p>
            <p className="text-xl font-bold font-display text-slate-900 dark:text-white">{marks.length}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-wrap gap-3 items-center">
        <SearchBar value={search} onChange={setSearch} placeholder="Search by student name or roll no..." className="flex-1 min-w-48" />
        <div className="relative">
          <select
            value={examTypeFilter}
            onChange={e => setExamTypeFilter(e.target.value)}
            className="input-field appearance-none pr-8 w-36 capitalize"
          >
            <option value="">All Exam Types</option>
            {EXAM_TYPES.map(t => <option key={t} value={t} className="capitalize">{t.replace('_', ' ')}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
        <div className="relative">
          <select
            value={subjectFilter}
            onChange={e => setSubjectFilter(e.target.value)}
            className="input-field appearance-none pr-8 w-40"
          >
            <option value="">All Subjects</option>
            {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-slate-400">
            <Award size={36} className="mb-3 opacity-40" />
            <p className="font-medium">No marks records found</p>
            <p className="text-sm mt-1 text-slate-500">Add marks to get started</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  {['Student', 'Subject', 'Exam Type', 'Marks', 'Percentage', 'Grade', 'Actions'].map(h => (
                    <th key={h} className="table-header text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(m => {
                  const pct = ((m.marks_obtained / m.total_marks) * 100).toFixed(1);
                  const grade = m.grade || calcGrade(m.marks_obtained, m.total_marks);
                  return (
                    <tr key={m.id} className="table-row group">
                      <td className="table-cell">
                        <div>
                          <p className="font-medium text-slate-900 dark:text-white text-sm">{(m as any).students?.name ?? '-'}</p>
                          <p className="text-xs text-slate-400 font-mono">{(m as any).students?.roll_number ?? ''}</p>
                        </div>
                      </td>
                      <td className="table-cell">
                        <p className="text-sm">{(m as any).subjects?.name ?? '-'}</p>
                        <p className="text-xs text-slate-400">{(m as any).subjects?.code ?? ''}</p>
                      </td>
                      <td className="table-cell">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 capitalize">
                          {m.exam_type.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="table-cell">
                        <span className="font-semibold text-slate-900 dark:text-white">{m.marks_obtained}</span>
                        <span className="text-slate-400 text-xs">/{m.total_marks}</span>
                      </td>
                      <td className="table-cell">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full max-w-16 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                Number(pct) >= 75 ? 'bg-emerald-500' : Number(pct) >= 50 ? 'bg-amber-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{pct}%</span>
                        </div>
                      </td>
                      <td className="table-cell">
                        <span className={`text-lg font-bold font-display ${gradeColor(grade)}`}>{grade}</span>
                      </td>
                      <td className="table-cell">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => openEdit(m)}
                            className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button
                            onClick={() => setDeleteId(m.id)}
                            className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editMark ? 'Edit Marks' : 'Add Marks'}
        size="md"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg px-3 py-2 text-sm">
              {formError}
            </div>
          )}

          <div>
            <label className="label">Student</label>
            <div className="relative">
              <select
                value={form.student_id}
                onChange={e => setForm(f => ({ ...f, student_id: e.target.value }))}
                className="input-field appearance-none pr-8"
                required
              >
                <option value="">Select Student</option>
                {students.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.roll_number})</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div>
            <label className="label">Subject</label>
            <div className="relative">
              <select
                value={form.subject_id}
                onChange={e => setForm(f => ({ ...f, subject_id: e.target.value }))}
                className="input-field appearance-none pr-8"
                required
              >
                <option value="">Select Subject</option>
                {subjects.map(s => (
                  <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Exam Type</label>
              <div className="relative">
                <select
                  value={form.exam_type}
                  onChange={e => setForm(f => ({ ...f, exam_type: e.target.value }))}
                  className="input-field appearance-none pr-8 capitalize"
                >
                  {EXAM_TYPES.map(t => <option key={t} value={t} className="capitalize">{t.replace('_', ' ')}</option>)}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>
            <div>
              <label className="label">Total Marks</label>
              <input
                type="number"
                value={form.total_marks}
                onChange={e => setForm(f => ({ ...f, total_marks: e.target.value }))}
                className="input-field"
                min="1"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Marks Obtained</label>
              <input
                type="number"
                value={form.marks_obtained}
                onChange={e => {
                  const val = e.target.value;
                  const obtained = parseFloat(val);
                  const total = parseFloat(form.total_marks);
                  const grade = !isNaN(obtained) && !isNaN(total) && total > 0
                    ? calcGrade(obtained, total)
                    : '';
                  setForm(f => ({ ...f, marks_obtained: val, grade }));
                }}
                className="input-field"
                min="0"
                required
              />
            </div>
            <div>
              <label className="label">Grade (auto)</label>
              <input
                type="text"
                value={form.grade}
                onChange={e => setForm(f => ({ ...f, grade: e.target.value }))}
                className="input-field"
                placeholder="Auto-calculated"
              />
            </div>
          </div>

          <div>
            <label className="label">Remarks</label>
            <textarea
              value={form.remarks}
              onChange={e => setForm(f => ({ ...f, remarks: e.target.value }))}
              rows={2}
              className="input-field resize-none"
              placeholder="Optional remarks"
            />
          </div>

          <div className="flex gap-3 pt-2 border-t border-slate-200 dark:border-slate-700">
            <button type="button" onClick={() => setModalOpen(false)} className="flex-1 btn-secondary">Cancel</button>
            <button type="submit" disabled={saving} className="flex-1 btn-primary">
              {saving ? 'Saving...' : editMark ? 'Update Marks' : 'Add Marks'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Record"
        message="This will permanently delete this marks record."
        loading={deleting}
      />
    </div>
  );
}
