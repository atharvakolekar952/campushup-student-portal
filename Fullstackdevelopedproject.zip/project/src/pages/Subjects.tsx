import React, { useEffect, useState, useCallback } from 'react';
import { BookOpen, Plus, Edit2, Trash2, ChevronDown } from 'lucide-react';
import { supabase, type Subject } from '../lib/supabase';
import Modal from '../components/Modal';
import ConfirmDialog from '../components/ConfirmDialog';
import SearchBar from '../components/SearchBar';

const CLASSES = ['10th', '11th', '12th'];

const emptyForm = { name: '', code: '', class: '' };

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [filtered, setFiltered] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editSubject, setEditSubject] = useState<Subject | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState('');

  const fetchSubjects = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('subjects').select('*').order('name');
    setSubjects(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetchSubjects(); }, [fetchSubjects]);

  useEffect(() => {
    let result = subjects;
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(s =>
        s.name.toLowerCase().includes(q) || s.code.toLowerCase().includes(q)
      );
    }
    if (classFilter) result = result.filter(s => s.class === classFilter);
    setFiltered(result);
  }, [subjects, search, classFilter]);

  const openAdd = () => {
    setEditSubject(null);
    setForm(emptyForm);
    setFormError('');
    setModalOpen(true);
  };

  const openEdit = (s: Subject) => {
    setEditSubject(s);
    setForm({ name: s.name, code: s.code, class: s.class || '' });
    setFormError('');
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);

    try {
      if (editSubject) {
        const { error } = await supabase.from('subjects').update(form).eq('id', editSubject.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('subjects').insert(form);
        if (error) throw error;
      }
      setModalOpen(false);
      fetchSubjects();
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : 'Failed to save subject');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleting(true);
    await supabase.from('subjects').delete().eq('id', deleteId);
    setDeleteId(null);
    setDeleting(false);
    fetchSubjects();
  };

  const classColors: Record<string, string> = {
    '10th': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
    '11th': 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
    '12th': 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div>
          <h1 className="page-header">Subjects</h1>
          <p className="text-sm text-slate-500 mt-0.5">{filtered.length} subjects</p>
        </div>
        <button onClick={openAdd} className="btn-primary ml-auto flex items-center gap-2">
          <Plus size={16} />
          Add Subject
        </button>
      </div>

      <div className="card p-4 flex flex-wrap gap-3 items-center">
        <SearchBar value={search} onChange={setSearch} placeholder="Search by name or code..." className="flex-1 min-w-48" />
        <div className="relative">
          <select
            value={classFilter}
            onChange={e => setClassFilter(e.target.value)}
            className="input-field appearance-none pr-8 w-32"
          >
            <option value="">All Classes</option>
            {CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map(s => (
            <div key={s.id} className="card p-5 hover:scale-[1.02] transition-transform duration-200 group">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                  <BookOpen size={18} className="text-white" />
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => openEdit(s)}
                    className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all"
                  >
                    <Edit2 size={13} />
                  </button>
                  <button
                    onClick={() => setDeleteId(s.id)}
                    className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-white text-sm">{s.name}</h3>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-xs font-mono text-slate-500 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded">
                  {s.code}
                </span>
                {s.class && (
                  <span className={`text-xs font-medium px-2 py-0.5 rounded ${classColors[s.class] ?? 'bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-400'}`}>
                    {s.class}
                  </span>
                )}
              </div>
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center py-16 text-slate-400">
              <BookOpen size={36} className="mb-3 opacity-40" />
              <p className="font-medium">No subjects found</p>
            </div>
          )}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editSubject ? 'Edit Subject' : 'Add Subject'}
        size="sm"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {formError && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 rounded-lg px-3 py-2 text-sm">
              {formError}
            </div>
          )}
          <div>
            <label className="label">Subject Name</label>
            <input
              type="text"
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              className="input-field"
              placeholder="e.g. Mathematics"
              required
            />
          </div>
          <div>
            <label className="label">Subject Code</label>
            <input
              type="text"
              value={form.code}
              onChange={e => setForm(f => ({ ...f, code: e.target.value.toUpperCase() }))}
              className="input-field font-mono"
              placeholder="e.g. MATH101"
              required
            />
          </div>
          <div>
            <label className="label">Class</label>
            <div className="relative">
              <select
                value={form.class}
                onChange={e => setForm(f => ({ ...f, class: e.target.value }))}
                className="input-field appearance-none pr-8"
              >
                <option value="">Select Class</option>
                {CLASSES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
          <div className="flex gap-3 pt-2 border-t border-slate-200 dark:border-slate-700">
            <button type="button" onClick={() => setModalOpen(false)} className="flex-1 btn-secondary">Cancel</button>
            <button type="submit" disabled={saving} className="flex-1 btn-primary">
              {saving ? 'Saving...' : editSubject ? 'Update' : 'Add Subject'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Subject"
        message="This will permanently delete this subject and all related records."
        loading={deleting}
      />
    </div>
  );
}
