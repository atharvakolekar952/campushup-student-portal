import React, { useState } from 'react';
import { GraduationCap, Mail, Lock, User, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function AuthPage() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) setError(error.message);
    } else {
      if (!fullName.trim()) { setError('Full name is required.'); setLoading(false); return; }
      const { error } = await signUp(email, password, fullName);
      if (error) setError(error.message);
      else setSuccess('Account created! You can now sign in.');
    }
    setLoading(false);
  };

  const switchMode = (m: 'login' | 'signup') => {
    setMode(m);
    setError('');
    setSuccess('');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 bg-grid">
      {/* Background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative animate-slide-up">
        {/* Card */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="px-8 pt-8 pb-6 text-center border-b border-slate-800">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-glow-blue">
              <GraduationCap size={28} className="text-white" />
            </div>
            <h1 className="font-display text-2xl font-bold text-white">CampusHub</h1>
            <p className="text-slate-400 text-sm mt-1">Student Management Portal</p>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-slate-800">
            {(['login', 'signup'] as const).map(m => (
              <button
                key={m}
                onClick={() => switchMode(m)}
                className={`flex-1 py-3.5 text-sm font-semibold capitalize transition-all duration-200 ${
                  mode === m
                    ? 'text-blue-400 border-b-2 border-blue-500 -mb-px'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="px-8 py-6 space-y-4">
            {error && (
              <div className="flex items-center gap-2 bg-red-900/30 border border-red-800 text-red-400 rounded-lg px-3 py-2.5 text-sm animate-fade-in">
                <AlertCircle size={15} />
                {error}
              </div>
            )}
            {success && (
              <div className="bg-emerald-900/30 border border-emerald-800 text-emerald-400 rounded-lg px-3 py-2.5 text-sm animate-fade-in">
                {success}
              </div>
            )}

            {mode === 'signup' && (
              <div>
                <label className="label text-slate-300">Full Name</label>
                <div className="relative">
                  <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    placeholder="John Doe"
                    required
                    className="input-field pl-9 bg-slate-800 border-slate-700 text-white placeholder-slate-500"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="label text-slate-300">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="admin@campushub.edu"
                  required
                  className="input-field pl-9 bg-slate-800 border-slate-700 text-white placeholder-slate-500"
                />
              </div>
            </div>

            <div>
              <label className="label text-slate-300">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={6}
                  className="input-field pl-9 pr-10 bg-slate-800 border-slate-700 text-white placeholder-slate-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-semibold rounded-lg transition-all duration-200 hover:shadow-glow-blue active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed mt-2"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {mode === 'login' ? 'Signing in...' : 'Creating account...'}
                </span>
              ) : (
                mode === 'login' ? 'Sign In' : 'Create Account'
              )}
            </button>

            {mode === 'login' && (
              <p className="text-xs text-slate-500 text-center pt-1">
                Demo: sign up with any email & password to get started
              </p>
            )}
          </form>
        </div>

        <p className="text-center text-xs text-slate-600 mt-6">
          Developed by <span className="text-blue-500">Atharva Kolekar</span>
        </p>
      </div>
    </div>
  );
}
